## todo list

- [ ] health
- [x] config
- [x] scoreboards
