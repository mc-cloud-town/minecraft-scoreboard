## todo list

- [ ] health
- [ ] config
- [ ] login
- [ ] scoreboards
- [ ] MCDR starsHelper support
