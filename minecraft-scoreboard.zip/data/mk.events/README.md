# events

- activation
- dead
- fly
- join
- placed_block
- unsneak
- used_tool
